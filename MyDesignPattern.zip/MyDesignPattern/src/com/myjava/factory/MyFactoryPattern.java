package com.myjava.factory;

import com.myjava.shape.Circle;
import com.myjava.shape.Rectangle;
import com.myjava.shape.Shape;
import com.myjava.shape.Triangle;

public class MyFactoryPattern {
	
	public Shape getShape(String shape){
		if(shape.equalsIgnoreCase("circle")){
			return new Circle();
		}
		if(shape.equalsIgnoreCase("rectangle")){
			return new Rectangle();
		}
		if(shape.equalsIgnoreCase("triangle")){
			return new Triangle();
		}
		return null;
	}
}
