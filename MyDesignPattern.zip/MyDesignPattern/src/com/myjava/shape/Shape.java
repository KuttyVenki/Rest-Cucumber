package com.myjava.shape;

public interface Shape {
public void draw();
}
