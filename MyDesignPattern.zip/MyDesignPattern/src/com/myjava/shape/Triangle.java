package com.myjava.shape;

public class Triangle implements Shape{

	@Override
	public void draw() {
		System.out.println("This draw method is from triangle");
	}
	
}
