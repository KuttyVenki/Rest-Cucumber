package com.myjava.shape;

public class Circle implements Shape {

	@Override
	public void draw() {
		System.out.println("This draw method is from Circle");
	}

}
