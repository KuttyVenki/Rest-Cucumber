package com.myjava.desginpattern;

import com.myjava.factory.MyFactoryPattern;
import com.myjava.shape.Shape;

public class MyFactoryDemo {

	public static void main(String[] args) {
		MyFactoryPattern myfactory=new MyFactoryPattern();
		Shape myShapeCir=myfactory.getShape("circle");
		myShapeCir.draw();
		
		Shape myShapeRec=myfactory.getShape("rectangle");
		myShapeRec.draw();
		
		Shape myShapeTri=myfactory.getShape("triangle");
		myShapeTri.draw();
	}

}
