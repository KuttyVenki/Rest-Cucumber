package com.myjava.calculation;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LamdaCalculate {

    public static void main(String[] args) {
        List <Integer> values=Arrays.asList(1,2,3,5,4,6,7,8,9,10);
        System.out.println(totalValues(values));
        System.out.println(totalEvenValues(values));
        System.out.println(totalOddValues(values));
        System.out.println(totalValuesPredicate(values,e->true));
        System.out.println(totalValuesPredicate(values,e->e%2==0));
        System.out.println(totalValuesPredicate(values,e->e%2!=0));
        System.out.println(totalValuesStream(values,e->true));
        System.out.println(totalValuesStream(values,e->e%2==0));
        System.out.println(totalValuesStream(values,e->e%2!=0));
        System.out.println(values.stream()
                                 .filter(e->e>3)
                                 .filter(e->e%2==0)
                                 .map(e->e*2)
                                 .findFirst()
                                 .orElse(0)
                );
        List<String> strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
        System.out.println(strings);
        System.out.println(strings.size());
        List<String> filtered = strings.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());
        System.out.println("filtered -->"+filtered);
        List<String> sorted = strings.stream().filter(string -> !string.isEmpty()).sorted().collect(Collectors.toList());
        System.out.println("sorted -->"+sorted);
        Collections.sort(strings, (s1,s2)->s1.compareTo(s2));
        System.out.println("collection sort "+strings);
        Collections.sort(strings);
        System.out.println("collection sort java 7"+strings);
        System.out.println("filtered string count-->"+strings.stream().filter(string -> !string.isEmpty()).count() );
        Stream<String> strings1=strings.stream().filter(string -> !string.isEmpty());
        //System.out.println("filtered string not empty -->"+strings1.collect(Collectors.toList()) );
        System.out.println("String limit"+strings1.limit(3).collect(Collectors.toList()));
        Random random = new Random();
        random.ints().limit(5).forEach(System.out::println);
        
        List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
        //get list of unique squares
        List<Integer> squaresList = numbers.stream().map( i -> i).distinct().collect(Collectors.toList());
        System.out.println("squaresList"+squaresList);
      
        List<String> parallelStr = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
        //get count of empty string
        long count =  parallelStr.parallelStream().filter(parallel -> !parallel.isEmpty()).count();
        System.out.println("parallel "+count);
        System.out.println("list empty check "+!values.isEmpty());
        // Collectors
        List<String>stringsCollect = Arrays.asList("ac","","bcd","efg","abcd","","jkl");
        List<String> filteredCollect = stringsCollect.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());

        System.out.println("Filtered List: " + filteredCollect);
        String mergedString = stringsCollect.stream().filter(string -> !string.isEmpty()).collect(Collectors.joining(","));
        System.out.println("Merged String: " + mergedString);
        String noCama=mergedString.replaceAll(",", " ");
        System.out.println("noCama "+noCama);
        
        List<Integer> numbers2 = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
        IntSummaryStatistics stats = numbers2.stream().mapToInt(x -> x).summaryStatistics();
        System.out.println("Highest number in List : " + stats.getMax());
        System.out.println("Lowest number in List : " + stats.getMin());
        System.out.println("Sum of all numbers : " + stats.getSum());
        System.out.println("Average of all numbers : " + stats.getAverage());
        // all match primitive
        boolean stats1 = numbers2.stream().allMatch(number->number>1);
        System.out.println("alll match > 1 "+stats1);
        boolean stats2 = numbers2.stream().anyMatch(number->number>5);
        System.out.println("any match > 5 "+stats2);
        //all match ,any match , none match String
        List<String> parallelStr1 = Arrays.asList("abc", "bad", "brac", "efag", "abcd","aa", "jakl");
        boolean starWithA=parallelStr1.stream().allMatch(str->str.startsWith("a"));
        System.out.println("starWithA "+starWithA);
        boolean anyWithA=parallelStr1.stream().anyMatch(str->str.startsWith("a"));
        System.out.println("anyWithA "+anyWithA);
        boolean anyWithf=parallelStr1.stream().noneMatch(str->str.startsWith("f"));
        System.out.println("NoneWithf "+anyWithf);
        // equals
        boolean isnumObjEquals=parallelStr.stream().equals(parallelStr);
        System.out.println("isnumObjEquals "+isnumObjEquals);
        // is parallel
        List<Integer> numbers4 = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
        boolean isparallel=numbers4.stream().isParallel();
        boolean isparallel1=numbers4.parallelStream().isParallel();
        System.out.println("isparallel "+isparallel);
        System.out.println("isparallel1 "+isparallel1);
        //count
        List<Integer> numbers5 = Arrays.asList(2,4, 2, 6, 3, 7, 3, 5);
        long numCount=numbers5.stream().count();
        System.out.println("numCount="+numCount);
        //find any
        Optional<Integer> numAny=numbers5.stream().filter(e->e>3).findAny();
        System.out.println("numAny "+numAny);
        Optional<Integer> numfindAny = numbers4.parallelStream().filter(i->i>3).findAny();
        System.out.println("numfindAny "+numfindAny);
        //find first
        Optional<Integer> numFirst=numbers5.stream().filter(e->e>3).findFirst();
        System.out.println("numFirst "+numFirst);
        HashSet<Integer> numSet=new HashSet<>();
        numSet.add(4);
        numSet.add(3);
        numSet.add(7);
        numSet.add(5);
        numSet.add(2);
        System.out.println("numSet "+numSet);
        // empty for each
        Stream<Integer> s=Stream.empty();
        s=numbers5.stream();
        s.forEach(System.out::println);
        // flat map 
        String[][] data = new String[][]{{"a", "b"}, {"c", "d"}, {"e", "f"}};
        //Stream<String[]>
        Stream<String[]> temp = Arrays.stream(data);
        //filter a stream of string[], and return a string[]?
        Stream<String[]> stream = temp.filter(x -> "a".equals(x.toString()));
        System.out.println("Flat map starts");
        stream.forEach(System.out::println);
        System.out.println("nothing printed above for sop ");
        //Stream<String[]>    -> flatMap -> Stream<String>
        Stream<String[]> temp1 = Arrays.stream(data);
        Stream<String> stringStream = temp1.flatMap(x -> Arrays.stream(x));
        System.out.println(temp1);
        System.out.println("Flat map no filter");
        Stream<String> streams = stringStream.filter(x -> x!=null);
        streams.forEach(System.out::println);
        System.out.println("Flat map with filter");
        // iterate , limit , skip and peek
        System.out.println("**** iterate , limit , skip and peek ******");
        Stream<Long> tenNaturalNumbers = Stream.iterate(1L, n  ->  n  + 1)
                .peek(n -> System.out.println("number generated: - " + n))
                .filter(number->!((number % 2) == 0))
                .peek(n->System.out.println("Even number filter passed for - " + n))
                .skip(10)
                .limit(10);
        tenNaturalNumbers.forEach(System.out::println);
        // toArray
        Stream<String> streamString = Stream.of("a", "b", "c");
        String[] stringArray = streamString.toArray(size -> new String[size]);
        Arrays.stream(stringArray).forEach(System.out::println);
    }
    
    public static int totalValues(List <Integer> values){
        int total =0;
        for(int e:values){
            total+=e;
        }
        return total;
    }
    public static int totalEvenValues(List <Integer> values){
        int total =0;
        for(int e:values){
            if(e%2==0){
                total+=e;
            }
        }
        return total;
    }
    public static int totalOddValues(List <Integer> values){
        int total =0;
        for(int e:values){
            if(e%2!=0){
                total+=e;
            }
        }
        return total;
    }
    public static int totalValuesPredicate(List <Integer> values,Predicate<Integer> selector){
        int total =0;
        for(int e:values){
            if(selector.test(e)){
                total+=e;
            }
        }
        return total;
    }
    public static int totalValuesStream(List <Integer> values,Predicate<Integer> selector){
        return values.stream()
                .filter(selector)
                .reduce(0, (c,e)->c+e);
    }
    public void newTry() {
        try(FileOutputStream fos = new FileOutputStream("movies.txt");
                    DataOutputStream dos = new DataOutputStream(fos)) {
              dos.writeUTF("Java 7 Block Buster");
        } catch(IOException e) {
              // log the exception
        }
    }
}
