package com.myjava.calculation;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class LamdaCalculate {

    public static void main(String[] args) {
        List <Integer> values=Arrays.asList(1,2,3,5,4,6,7,8,9,10);
        System.out.println(totalValues(values));
        System.out.println(totalEvenValues(values));
        System.out.println(totalOddValues(values));
        System.out.println(totalValuesPredicate(values,e->true));
        System.out.println(totalValuesPredicate(values,e->e%2==0));
        System.out.println(totalValuesPredicate(values,e->e%2!=0));
        System.out.println(totalValuesStream(values,e->true));
        System.out.println(totalValuesStream(values,e->e%2==0));
        System.out.println(totalValuesStream(values,e->e%2!=0));
        System.out.println(values.stream()
                                 .filter(e->e>3)
                                 .filter(e->e%2==0)
                                 .map(e->e*2)
                                 .findFirst()
                                 .orElse(0)
                );
    }
    
    public static int totalValues(List <Integer> values){
        int total =0;
        for(int e:values){
            total+=e;
        }
        return total;
    }
    public static int totalEvenValues(List <Integer> values){
        int total =0;
        for(int e:values){
            if(e%2==0){
                total+=e;
            }
        }
        return total;
    }
    public static int totalOddValues(List <Integer> values){
        int total =0;
        for(int e:values){
            if(e%2!=0){
                total+=e;
            }
        }
        return total;
    }
    public static int totalValuesPredicate(List <Integer> values,Predicate<Integer> selector){
        int total =0;
        for(int e:values){
            if(selector.test(e)){
                total+=e;
            }
        }
        return total;
    }
    public static int totalValuesStream(List <Integer> values,Predicate<Integer> selector){
        return values.stream()
                .filter(selector)
                .reduce(0, (c,e)->c+e);
    }
    public void newTry() {
        try(FileOutputStream fos = new FileOutputStream("movies.txt");
                    DataOutputStream dos = new DataOutputStream(fos)) {
              dos.writeUTF("Java 7 Block Buster");
        } catch(IOException e) {
              // log the exception
        }
    }
}
