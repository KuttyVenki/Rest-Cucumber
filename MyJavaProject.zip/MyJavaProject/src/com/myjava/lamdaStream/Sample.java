package com.myjava.lamdaStream;

public class Sample {

    interface Fly{
        public void fly();
        default public void cruise(){System.out.println("FLY::cruise");}
        default public void turn(){System.out.println("FLY::turn");}
        default public void takeoff(){System.out.println("FLY::takeoff");}
        default public void land(){System.out.println("FLY::land");}
    }
    interface FastFly extends Fly{
        default public void takeoff(){System.out.println("FastFLY::takeoff");}
    }
    class Vehicle {
         public void land(){System.out.println("Vehicle::land");}
    }
    interface Sail{
        default public void cruise(){System.out.println("Sail::cruise");}
    }
    class SeaPlane extends Vehicle implements FastFly,Sail{
        @Override
        public void fly() {
            System.out.println("Seaplane::fly");
        }
        @Override
        public void cruise() {
            System.out.println("Seaplane::cruise");
            Sail.super.cruise();
        }
    }
    public static void main(String[] args) {
        System.out.println("Sample main");
        new Sample().use();
    }
    public void use(){
        SeaPlane seaPlane=new SeaPlane();
        seaPlane.fly();
        seaPlane.takeoff();
        seaPlane.cruise();
        seaPlane.land();
    }

}
