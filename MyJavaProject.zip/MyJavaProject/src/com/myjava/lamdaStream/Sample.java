package com.myjava.lamdaStream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.IntFunction;
import java.util.stream.Collectors;

public class Sample {
    

    interface Fly{
        public void fly();
        default public void cruise(){System.out.println("FLY::cruise");}
        default public void turn(){System.out.println("FLY::turn");}
        default public void takeoff(){System.out.println("FLY::takeoff");}
        default public void land(){System.out.println("FLY::land");}
    }
    interface FastFly extends Fly{
        default public void takeoff(){System.out.println("FastFLY::takeoff");}
    }
    class Vehicle {
         public void land(){System.out.println("Vehicle::land");}
    }
    interface Sail{
        default public void cruise(){System.out.println("Sail::cruise");
        }
    }
    class SeaPlane extends Vehicle implements FastFly,Sail{
        @Override
        public void fly() {
            System.out.println("Seaplane::fly");
        }
        @Override
        public void cruise() {
            System.out.println("Seaplane::cruise");
            Sail.super.cruise();
        }
    }
    public static void main(String[] args) {
        System.out.println("Sample main");
        new Sample().use();
        User user1=new User();
        user1.setUserName("Sami");
        user1.setPassWord("pwd");
        user1.setAge(12);
        User user2= new User();
        user2.setUserName("Rajesh");
        user2.setPassWord("pwd");
        user2.setAge(16);
        User user3=new User();
        user3.setUserName("Palani");
        user3.setPassWord("pwd");
        user3.setAge(19);
        List<User> userList = Arrays.asList(user1,user2,user3);
        System.out.println(user1.getUserName().contains("SamiKannu"));
        // name contains sami
        List<User> listUser=userList.stream().filter(user->user.getUserName().contains("Sami")).collect(Collectors.toList());
        System.out.println(listUser.size());
        System.out.println("listUser"+listUser+" userList "+userList);
        // name start with sami
        List<User> listUser1=userList.stream().filter(user->user.getUserName().startsWith("Sami")).collect(Collectors.toList());
        System.out.println(listUser1.size());
        System.out.println("listUser1"+listUser1);
        //sort by age
        Map<String, List<User>> personsByAge=userList.stream().collect(Collectors.groupingBy(user -> user.getUserName()));
        personsByAge.forEach((userName, user) -> System.out.format("age %s: %s\n", userName, user));
    }
/*    private static Optional<Boolean> totalOddValues(List<User> listUser) {
       System.out.println(listUser.stream()
               .map(user->user!=null)
               .reduce((user,user1)->user1.booleanValue()));
        IntFunction generator;
        return null
                ;
    }*/
    public void use(){
        SeaPlane seaPlane=new SeaPlane();
        seaPlane.fly();
        seaPlane.takeoff();
        seaPlane.cruise();
        seaPlane.land();
        seaPlane.turn();
    }
}
