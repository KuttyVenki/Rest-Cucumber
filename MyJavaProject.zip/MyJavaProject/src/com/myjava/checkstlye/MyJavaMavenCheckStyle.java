package com.myjava.checkstlye;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class MyJavaMavenCheckStyle {
private static String mvnVersion=null;
  public static void main(String args[]){
      System.out.println("mvn version "+mvnVersion);
      List <Integer> values=Arrays.asList(1,2,3,4,5,6);
      new MyJavaMavenCheckStyle().printList(values);
      new MyJavaMavenCheckStyle().printTotal(values);
     }
  
  public void printList(List<Integer> values){
      // java 4 
      for (int i=0;i<values.size();i++){
          System.out.println("value in i "+values.get(i));
          }
      // imperative enhanced for loop   external iterator
      for (int value:values){
          System.out.println("value in enhanced for loop "+value);
          }
      // internal iterator
      values.forEach(new Consumer<Integer>(){
          @Override
          public void accept(Integer t) {
              System.out.println(t);
              }
          }
       );
      // lamda noisy 
      values.forEach((Integer value) -> System.out.println("fist lamda "+value));
      // lamda 
      values.forEach((value)->System.out.println("lamda updated "+value));
      // lamda advanced
      values.forEach(value->System.out.println("lamda advanced "+value));
      // lamda expert
      values.forEach(System.out::println);
  }
  public void printTotal(List<Integer> values){
      int total=0;
      for(int e:values){
          total+=e*2;
      }
      System.out.println("total from imperative"+total);
      
      System.out.println("total from stream "+
            values.stream()
                  .map(e->e*2)
                  .reduce(0,(c,e)->c+e) );
  }
}
