package com.myjava.java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MinMax {

    public static void main(String[] args) {
        Person obama = new Person("Barack Obama", 53);
        Person bush2 = new Person("George Bush", 68);
        Person clinton = new Person("Bill Clinton", 68);
        Person bush1 = new Person("George HW Bush", 90);
    
        Person[] personArray = new Person[] {obama, bush2, clinton, bush1};
        List<Person> personList = Arrays.asList(personArray);

       //Find Oldest Person
       final Comparator<Person> comp = (p1, p2) -> Integer.compare( p1.getAge(), p2.getAge());
       Person oldest = personList.stream()
                                 .max(comp)
                                 .get();
       System.out.println("old name "+oldest.getName() +" old age"+oldest.getAge());

       //Find Youngest Person
       //  -This time instead create the Comparator as the argument to the min() method
       Person youngest = personList.stream()
                                   .min((p1, p2) -> Integer.compare(p1.getAge(), p2.getAge()))
                                   .get();
       System.out.println("young name "+youngest.getName() +" young age"+youngest.getAge());
    }

}
