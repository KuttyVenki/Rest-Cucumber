package com.myjava.java8.streams.staticmethod;

import java.util.Arrays;
import java.util.Random;
import java.util.stream.Stream;

public class StreamStaticMethod {
    public static void main(String[] args) {
        StreamStaticMethod streamMethod=new StreamStaticMethod();
        // Concat
        // Merge two streams
        streamMethod.mergeTwoStream();
        // Merge more than 2 streams
        streamMethod.mergeMorethantwoStream();
        // Merge more than 2 streams using FlatMap
        streamMethod.mergeUsingFlatMap();
        //generate builder
        streamMethod.generateAndBuilder();
    }
    public void mergeTwoStream(){
        String[] arr1 = { "a", "b", "c", "d" };
        String[] arr2 = { "e", "f", "g" };
        Stream <String> str1=Stream.of(arr1);
        Stream <String> str2=Stream.of(arr2);
        Stream <String> str3=Stream.concat(str1, str2);
        // str3.forEach(System.out::println);
        String[] stringArray = str3.toArray(size -> new String[size]);
        System.out.println(Arrays.toString(stringArray));
    }
    public void mergeMorethantwoStream(){
        String[] arr3 = { "a", "b", "c", "d" };
        String[] arr4 = { "e", "f", "g" };
        String[] arr5 = { "h", "i", "j" };
        Stream <String> str4=Stream.of(arr3);
        Stream <String> str5=Stream.of(arr4);
        Stream <String> str6=Stream.concat(str4, str5);
        Stream <String> str8=Stream.of(arr5);
        Stream <String> str7=Stream.concat(str6,str8);
        Stream <String> str9=Stream.of(arr3);;//str4;
        System.out.println(str9.equals(str4));
        // str7.forEach(System.out::println);
        String[] stringArray1 = str7.toArray(size -> new String[size]);
        System.out.println(Arrays.toString(stringArray1));
    }
    public void generateAndBuilder(){
        Stream.generate(new Random()::nextFloat)
        .limit(10)
        .forEach(System.out::println); 
        Stream<String> streamBuilder =
                Stream.<String>builder().add("a").add("b").add("c").build();
        streamBuilder.forEach(System.out::println);
    }
    public void mergeUsingFlatMap(){
        String[] arr1 = { "a", "b", "c", "d" };
        String[] arr2 = { "e", "f", "g" };
        String[] arr3 = { "h", "i", "j" };
        Stream <String> str1=Stream.of(arr1);
        Stream <String> str2=Stream.of(arr2);
        Stream <String> str3=Stream.of(arr3);
        Stream <String> str4=Stream.of(str1,str2,str3).flatMap(x->x);
        String[] stringArray = str4.toArray(size -> new String[size]);
        System.out.println(Arrays.toString(stringArray));
    }
}
