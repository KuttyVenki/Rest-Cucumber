package com.javabrains.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.javabrains.hibernate.dto.AddressOne;
import com.javabrains.hibernate.dto.UserDetailsOne;

public class HibernatTestOne {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		UserDetailsOne userDetails=new UserDetailsOne();
		//userDetails.setUserId(1);
		userDetails.setUserName("Rajesh");
		AddressOne addr=new AddressOne();
		addr.setStreetName("Red Winesap way");
		addr.setCity("Dublin");
		addr.setState("Ohio");
		addr.setZipCode(43016);
		userDetails.setHomeAddress(addr);
		
		AddressOne officeAddr=new AddressOne();
		officeAddr.setStreetName("Rings road");
		officeAddr.setCity("Dublin");
		officeAddr.setState("Ohio");
		officeAddr.setZipCode(43017);
		userDetails.setOfficeAddress(officeAddr);
		System.out.println("First Hibernate ");
		
		UserDetailsOne userTwo	=new UserDetailsOne();
		//userDetails.setUserId(1);
		userTwo.setUserName("Karuppu");
		AddressOne addrTwo=new AddressOne();
		addrTwo.setStreetName("Sylvia dr");
		addrTwo.setCity("Dublin");
		addrTwo.setState("Ohio");
		addrTwo.setZipCode(43016);
		userTwo.setHomeAddress(addrTwo);
		
		AddressOne officeAddrK=new AddressOne();
		officeAddrK.setStreetName("Virtusa Road");
		officeAddrK.setCity("Dublin");
		officeAddrK.setState("Ohio");
		officeAddrK.setZipCode(43017);
		userTwo.setOfficeAddress(officeAddrK);
		
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.save(userTwo);
		session.getTransaction().commit();
		session.close();
		
		session = sessionFactory.openSession();
		session.beginTransaction();
		userDetails = (UserDetailsOne) session.get(UserDetailsOne.class,1);
		System.out.println("DB user id "+userDetails.getUserId()+" name "+userDetails.getUserName());
	}
}
