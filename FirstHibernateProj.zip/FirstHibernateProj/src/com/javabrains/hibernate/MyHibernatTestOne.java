package com.javabrains.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.javabrains.hibernate.dto.MyAddressOne;
import com.javabrains.hibernate.dto.MyUserDetailsOne;

public class MyHibernatTestOne {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyUserDetailsOne userDetails=new MyUserDetailsOne();
		//userDetails.setUserId(1);
		userDetails.setUserName("Rajesh");
		MyAddressOne addr=new MyAddressOne();
		addr.setStreetName("Red Winesap way");
		addr.setCity("Dublin");
		addr.setState("Ohio");
		addr.setZipCode(43016);
		
		MyAddressOne officeAddr=new MyAddressOne();
		officeAddr.setStreetName("Rings road");
		officeAddr.setCity("Dublin");
		officeAddr.setState("Ohio");
		officeAddr.setZipCode(43017);
		System.out.println("First Hibernate ");
		userDetails.getListOfAddresses().add(officeAddr);
		userDetails.getListOfAddresses().add(addr);
		
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.getTransaction().commit();
		session.close();
		userDetails=null;
		session = sessionFactory.openSession();
		session.beginTransaction();
		userDetails = (MyUserDetailsOne) session.get(MyUserDetailsOne.class,1);
		System.out.println("DB my user id "+userDetails.getUserId()+" name "+userDetails.getUserName());
		session.close();
		int addressCount=userDetails.getListOfAddresses().size();
		System.out.println("address count ="+addressCount);
	}
}
