package com.javabrains.hibernate.dto;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class VehicleTwo {
	@Id @GeneratedValue
	private int vehicleId;
	private String vehicleName;
/*	@ManyToOne
	@JoinColumn(name="USER_ID")*/
/*	private MyUserDetailsTwo userDetailsTwo;
	public MyUserDetailsTwo getUserDetailsTwo() {
		return userDetailsTwo;
	}
	public void setUserDetailsTwo(MyUserDetailsTwo userDetailsTwo) {
		this.userDetailsTwo = userDetailsTwo;
	}*/
	@ManyToMany(mappedBy="vehicleTwo")
	private Collection<MyUserDetailsTwo> userDetailsTwoList= new ArrayList<MyUserDetailsTwo>();
	
	public Collection<MyUserDetailsTwo> getUserDetailsTwo() {
		return userDetailsTwoList;
	}
	public void setUserDetailsTwo(Collection<MyUserDetailsTwo> userDetailsTwoList) {
		this.userDetailsTwoList = userDetailsTwoList;
	}
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
}
