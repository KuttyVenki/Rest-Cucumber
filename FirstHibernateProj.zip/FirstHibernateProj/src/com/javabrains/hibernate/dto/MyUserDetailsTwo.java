package com.javabrains.hibernate.dto;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table (name="MY_USER_DETAILS_TWO")
public class MyUserDetailsTwo {
	@Id @GeneratedValue
	private int userId;
	private String userName;
/*	@OneToOne
	@JoinColumn(name="VEHICLE_ID")*/
	//@OneToMany(mappedBy="userDetailsTwo")
	/*private VehicleTwo vehicleTwo;
	public VehicleTwo getVehicleTwo() {
		return vehicleTwo;
	}
	public void setVehicleTwo(VehicleTwo vehicleTwo) {
		this.vehicleTwo = vehicleTwo;
	}*/
	/*@JoinTable(name="USER_VEHICLE", joinColumns=@JoinColumn(name="USER_ID"), 
			inverseJoinColumns=@JoinColumn(name="VEHICLE_ID")
			)*/
	@ManyToMany
	private Collection<VehicleTwo> vehicleTwo = new ArrayList<VehicleTwo>();
	
	public Collection<VehicleTwo> getVehicleTwo() {
		return vehicleTwo;
	}
	public void setVehicleTwo(Collection<VehicleTwo> vehicleTwo) {
		this.vehicleTwo = vehicleTwo;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
