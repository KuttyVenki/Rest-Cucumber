package com.javabrains.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.javabrains.hibernate.dto.MyUserDetailsTwo;
import com.javabrains.hibernate.dto.VehicleTwo;

public class MyHibernatTestTwo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyUserDetailsTwo userDetails=new MyUserDetailsTwo();
		//userDetails.setUserId(1);
		userDetails.setUserName("Rajesh");
		VehicleTwo vehicle=new VehicleTwo();
		vehicle.setVehicleName("Car");
		//userDetails.setVehicleTwo(vehicle);
		VehicleTwo vehicle2=new VehicleTwo();
		vehicle2.setVehicleName("Car");
		userDetails.getVehicleTwo().add(vehicle);
		userDetails.getVehicleTwo().add(vehicle2);
	/*	vehicle.setUserDetailsTwo(userDetails);
		vehicle2.setUserDetailsTwo(userDetails);*/
		vehicle.getUserDetailsTwo().add(userDetails);
		vehicle2.getUserDetailsTwo().add(userDetails);
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.save(vehicle);
		session.save(vehicle2);
		session.getTransaction().commit();
		session.close();

	}
}
