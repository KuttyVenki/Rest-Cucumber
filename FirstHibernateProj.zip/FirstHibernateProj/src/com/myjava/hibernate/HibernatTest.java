package com.myjava.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.myjava.hibernate.dto.Address;
import com.myjava.hibernate.dto.UserDetails;

public class HibernatTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		UserDetails userDetails=new UserDetails();
		//userDetails.setUserId(1);
		userDetails.setUserName("Rajesh");
		Address addr=new Address();
		addr.setStreetName("Red Winesap way");
		addr.setCity("Dublin");
		addr.setState("Ohio");
		addr.setZipCode(43016);
		userDetails.setHomeAddress(addr);
		
		Address officeAddr=new Address();
		officeAddr.setStreetName("Rings road");
		officeAddr.setCity("Dublin");
		officeAddr.setState("Ohio");
		officeAddr.setZipCode(43017);
		userDetails.setOfficeAddress(officeAddr);
		System.out.println("First Hibernate ");
		
		UserDetails userTwo	=new UserDetails();
		//userDetails.setUserId(1);
		userTwo.setUserName("Karuppu");
		Address addrTwo=new Address();
		addrTwo.setStreetName("Sylvia dr");
		addrTwo.setCity("Dublin");
		addrTwo.setState("Ohio");
		addrTwo.setZipCode(43016);
		userTwo.setHomeAddress(addrTwo);
		
		Address officeAddrK=new Address();
		officeAddrK.setStreetName("Virtusa Road");
		officeAddrK.setCity("Dublin");
		officeAddrK.setState("Ohio");
		officeAddrK.setZipCode(43017);
		userTwo.setOfficeAddress(officeAddrK);
		
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(userDetails);
		session.save(userTwo);
		session.getTransaction().commit();
		session.close();
		
		session = sessionFactory.openSession();
		session.beginTransaction();
		userDetails = (UserDetails) session.get(UserDetails.class,1);
		System.out.println("DB user id "+userDetails.getUserId()+" name "+userDetails.getUserName());
	}
}
