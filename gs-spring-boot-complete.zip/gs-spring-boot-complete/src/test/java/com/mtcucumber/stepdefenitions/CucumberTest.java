package com.mtcucumber.stepdefenitions;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources",tags="@1234,@12345")
public class CucumberTest {
	
}