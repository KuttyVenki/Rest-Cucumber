
package com.mtcucumber.stepdefenitions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.resource.countries.Country;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@Component
public class StepDefinition {
	RestTemplate restTemplate = new RestTemplate();
	

    
	@Given("^I navigate to (.*)$")
	public void i_navigate_to_http_localhost_hello(String url) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("url"+url);
		String cucumberVersion = restTemplate.getForObject(url, String.class);
		System.out.println("cucumberVersion"+cucumberVersion);
	}

	@When("^I click on enter$")
	public void i_click_on_enter() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I should get the Cucumber version$")
	public void i_should_get_the_Cucumber_version() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^I enter put url to (.*)$")
	public void i_enter_put_url_to_http_localhost_countries(String url) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Country country = new Country();
		country.setCountryCode("US");
		country.setCountryName("United States");
		System.out.println("Country name before put "+country.getCountryName());
		 Map<String, String> params = new HashMap<String, String>();
		    params.put("id", "2");
		      restTemplate.put(url, country, params);;
	}

	@When("^I click on ok$")
	public void i_click_on_ok() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I should get the country response$")
	public void i_should_get_the_country_response() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

   
}