package hello;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.resource.countries.Country;

//@RequestMapping(value="/countries")
@RestController
public class HelloController {
	@RequestMapping(method={RequestMethod.GET},value={"/hello"})
    public String getVersion() {
		System.out.println("REst template get ");
		String CucumberVersion ="2";
        return CucumberVersion;
    }
	
    @RequestMapping(value="/countries/{countryId}",method=RequestMethod.PUT)
    public Country putCountry(@PathVariable(value="countryId") long countryId,@RequestBody Country country) {
    	System.out.println("countryId"+countryId);
    	System.out.println("countryId in body "+country.getCountryId());
    	System.out.println("country name"+country.getCountryName());
    	System.out.println("countrycode "+country.getCountryCode());
        return country;
    }
}
